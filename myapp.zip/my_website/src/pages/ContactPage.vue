<template>
    <h1 class="text-4xl font-bold text-center mb-8">Contact Me</h1>
    <div class="box max-w-lg mx-auto p-4 bg-black text-white">
      <p>You can email me at keeganasmith2003@tamu.edu</p>
    </div>
</template>