<template>
<GoogleSignin></GoogleSignin>
</template>

<script setup>
import GoogleSignin from '../components/GoogleSignin.vue';
</script>