<template>
  
    <h1 class="text-4xl font-bold text-center mb-8">About Keegan Smith</h1>
    <div class="box max-w-lg mx-auto p-4 bg-black text-white">
      <p>Howdy! I am a computer science student at Texas A&M University, and an avid programmer.</p>
      <br>
      <p>I have professional experience creating and deploying full stack web applications, creating automation software, and developing iOS applications.</p>
    </div>
</template>

<script setup>
  // import { defineProps } from "vue";
  // const props = defineProps({
  //   msg: String,
  // });
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
